module.exports={
	secret:'yu',//token加密的密钥
	secretTime:60*60*3,//3h
	uploadDir:'/upload/',//文件上传存放的文件夹
	baseUrl:'http://127.0.0.1'//当前项目的域名
}